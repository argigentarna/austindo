package com.example.austindo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
